﻿namespace UniversityClubDB
{


    partial class uni_club_membershipDataSet
    {
    }
}

namespace UniversityClubDB.uni_club_membershipDataSetTableAdapters {
    
    
    public partial class club_memberTableAdapter {
    }
}
